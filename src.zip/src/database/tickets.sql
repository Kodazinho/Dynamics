CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    game_name VARCHAR(255) NOT NULL,
    gamepass_name VARCHAR(255) NOT NULL,
    gamepass_price INT NOT NULL,
    roblox_nick VARCHAR(100) NOT NULL,
    pix_payment_id VARCHAR(50),
    status ENUM('PENDING', 'PAID') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_percent INT NOT NULL,
    max_uses INT NOT NULL,
    used_count INT DEFAULT 0,
    expires_at DATETIME NOT NULL,
    booster BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE tickets ADD COLUMN coupon_code VARCHAR(50) DEFAULT NULL;
ALTER TABLE tickets ADD COLUMN original_price DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE tickets ADD COLUMN final_price DECIMAL(10,2) DEFAULT NULL;
